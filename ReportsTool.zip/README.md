# PowerShell Scripts that I use for work within Microsoft 365, Azure and other Microsoft Products for efficient productivity
# These scripts are a combination of hand coded and GitHub Copilot creation/augmentation
# None of the scripts here are licensed or copyrighted are are free to use, alter, edit, refactor and share
