# Check if the Teams PowerShell module is installed
if (Get-Module -ListAvailable -Name MicrosoftTeams) {
    # If the Teams PowerShell module is installed, continue with the script
}
else {
    # If the Teams PowerShell module is not installed, prompt the user to install it
    $install = read-host "Teams PowerShell module is not installed. Would you like to install it? (Y/N)"
    # If the user selects Y, install the Teams PowerShell module
    if ($install -eq "Y") {
        # Install Teams PowerShell module
        Install-Module -Name MicrosoftTeams -Force
    }
    # If the user selects N, exit the script
    elseif ($install -eq "N") {
        exit
    }
}
# If the Teams PowerShell module is installed, continue with the script
# Connect to Teams PowerShell
Connect-MicrosoftTeams
# Get all Teams and create a variable to store them
$Teams = Get-Team | Select-Object -Property DisplayName, Description, Visbility, MailNickName, Classification, Archived
# Ask user if they would like to export the data to a CSV file
$export = read-host "Would you like to export the data to a CSV file? (Y/N)"
# If the user selects Y, export the data to a CSV file to a path of their choice
if ($export -eq "Y") {
    $path = read-host "Please enter the path you would like to export the data to"
    $Teams | Select-Object -Property DisplayName, Description, Visbility, MailNickName, Classification, Archived | Export-Csv -NoTypeInformation -Path $path
}
# Disconnect from Teams
Disconnect-MicrosoftTeams
# Ask the user if they would like to exit or return to the main menu
$exit = read-host "Would you like to exit or return to the main menu? (Exit/Menu)"
# If the user selects Exit, exit the script
if ($exit -eq "Exit") {
    exit
}
# If the user selects Menu, clear the terminal and return to the main menu
elseif ($exit -eq "Menu") {
    clear-host
    # Run the Main.ps1 script
    .\Main.ps1
}